CUSTOM SKINS — v1.2.0

Remplace Paul.png en mémoire avec un atlas PNG 64x64. Aucun fichier du jeu n’est modifié.

Compatibilité multijoueur : expose une petite API locale en mémoire permettant à Multiplayer Test de lire l’atlas actif et de le transmettre au joueur distant. Le skin de l’autre joueur n’écrase jamais le skin local.

Pour synchroniser les skins, installe également Multiplayer Test v0.2.0 sur les deux clients.
