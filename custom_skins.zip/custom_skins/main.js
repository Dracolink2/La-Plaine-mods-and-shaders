/* Custom Skins — La Plaine 0.2.7.0
 * Remplace Paul.png à la volée : aucun fichier du jeu n'est écrasé.
 * Le skin est conservé uniquement pendant l'onglet/la session du navigateur.
 */
(function () {
    'use strict';

    const SESSION_KEY = 'laPlaine.customSkin.ram';
    const DEFAULT_SKIN = '/static/textures/others/Paul.png';
    const MAX_FILE_BYTES = 2 * 1024 * 1024;
    let activeSkin = null;

    // sessionStorage sert uniquement de relais entre le menu et la page du jeu.
    // Il est effacé dès que Paul.png est demandé par le moteur.
    try { activeSkin = sessionStorage.getItem(SESSION_KEY) || null; } catch (_) {}

    function isPaulPath(value) {
        if (typeof value !== 'string') return false;
        return value === DEFAULT_SKIN || value.endsWith('/static/textures/others/Paul.png');
    }

    // Le moteur charge le personnage avec new Image().src = Paul.png.
    // On redirige cette demande vers l'atlas choisi, sans toucher à player.js.
    function installInMemoryReplacement() {
        if (window.__lpCustomSkinInterceptorInstalled) return;
        const descriptor = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'src');
        if (!descriptor || typeof descriptor.set !== 'function' || typeof descriptor.get !== 'function') {
            console.warn('[Custom Skins] Impossible d’installer le remplacement mémoire de Paul.png.');
            return;
        }
        Object.defineProperty(HTMLImageElement.prototype, 'src', {
            configurable: descriptor.configurable,
            enumerable: descriptor.enumerable,
            get: descriptor.get,
            set(value) {
                if (activeSkin && isPaulPath(String(value))) {
                    const replacement = activeSkin;
                    try { sessionStorage.removeItem(SESSION_KEY); } catch (_) {}
                    descriptor.set.call(this, replacement);
                    console.info('[Custom Skins] Paul.png remplacé en mémoire par le skin personnalisé.');
                    return;
                }
                descriptor.set.call(this, value);
            }
        });
        window.__lpCustomSkinInterceptorInstalled = true;
    }

    function setSkin(dataUrl) {
        activeSkin = dataUrl;
        // Relais temporaire pour le cas où le skin est choisi depuis le menu
        // principal avant le chargement de la page de jeu.
        try { sessionStorage.setItem(SESSION_KEY, dataUrl); } catch (_) {}

        // Si le joueur existe déjà (menu pause), son écouteur natif actualise
        // immédiatement les matériaux de son modèle.
        window.dispatchEvent(new CustomEvent('laplaine:custom-skin-changed', {
            detail: { dataUrl }
        }));
    }

    function resetSkin() {
        activeSkin = null;
        try { sessionStorage.removeItem(SESSION_KEY); } catch (_) {}
        window.dispatchEvent(new CustomEvent('laplaine:custom-skin-changed', {
            detail: { dataUrl: DEFAULT_SKIN }
        }));
    }

    function addStyles() {
        if (document.getElementById('lp-custom-skins-style')) return;
        const style = document.createElement('style');
        style.id = 'lp-custom-skins-style';
        style.textContent = `
            .lp-skin-panel{display:grid;grid-template-columns:112px 1fr;gap:18px;align-items:center;padding:14px;border:1px solid rgba(255,255,255,.14);border-radius:12px;background:rgba(0,0,0,.16);margin:12px 0}
            .lp-skin-preview{width:112px;height:112px;object-fit:contain;image-rendering:pixelated;background:rgba(0,0,0,.24);border-radius:8px}
            .lp-skin-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
            .lp-skin-status{display:block;margin-top:9px;color:#cbd5e1;font-size:13px;line-height:1.4}
            .lp-skin-file{display:none}
            @media(max-width:520px){.lp-skin-panel{grid-template-columns:1fr}.lp-skin-preview{width:96px;height:96px}}
        `;
        document.head.appendChild(style);
    }

    function buildPanel(container) {
        addStyles();
        const panel = document.createElement('div');
        panel.className = 'lp-skin-panel';

        const preview = document.createElement('img');
        preview.className = 'lp-skin-preview';
        preview.alt = 'Aperçu de l’atlas de skin';
        preview.src = activeSkin || DEFAULT_SKIN;

        const content = document.createElement('div');
        const heading = document.createElement('strong');
        heading.textContent = 'Skin du joueur';
        const description = document.createElement('p');
        description.className = 'setting-description';
        description.textContent = 'Importe un atlas PNG de 64 × 64 pixels organisé comme Paul.png. Le mod remplace Paul.png à la volée en mémoire : aucun fichier du jeu n’est modifié et le skin personnalisé est oublié à la fermeture de la session.';

        const file = document.createElement('input');
        file.type = 'file';
        file.accept = 'image/png,.png';
        file.className = 'lp-skin-file';

        const actions = document.createElement('div');
        actions.className = 'lp-skin-actions';
        const importButton = document.createElement('button');
        importButton.type = 'button';
        importButton.className = 'btn-menu small';
        importButton.textContent = 'IMPORTER UN ATLAS';
        const resetButton = document.createElement('button');
        resetButton.type = 'button';
        resetButton.className = 'btn-menu small';
        resetButton.textContent = 'SKIN PAR DÉFAUT';
        const status = document.createElement('small');
        status.className = 'lp-skin-status';
        status.textContent = activeSkin ? 'Un skin personnalisé est actif pour cette session.' : 'Format attendu : PNG 64 × 64.';

        importButton.addEventListener('click', () => file.click());
        file.addEventListener('change', async () => {
            const selected = file.files && file.files[0];
            if (!selected) return;
            if ((selected.type && selected.type !== 'image/png') || selected.size > MAX_FILE_BYTES) {
                status.textContent = 'Fichier refusé : sélectionne un PNG de 2 Mo maximum.';
                file.value = '';
                return;
            }
            try {
                const bitmap = await createImageBitmap(selected);
                const valid = bitmap.width === 64 && bitmap.height === 64;
                bitmap.close?.();
                if (!valid) {
                    status.textContent = 'Dimensions incorrectes : l’atlas doit mesurer exactement 64 × 64 pixels.';
                    file.value = '';
                    return;
                }
                const dataUrl = await new Promise((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onload = () => resolve(reader.result);
                    reader.onerror = () => reject(new Error('Lecture du fichier impossible.'));
                    reader.readAsDataURL(selected);
                });
                if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/png;base64,')) {
                    throw new Error('Le PNG sélectionné n’a pas pu être converti.');
                }
                setSkin(dataUrl);
                preview.src = dataUrl;
                status.textContent = `Skin « ${selected.name} » chargé : il remplace Paul.png en mémoire.`;
            } catch (error) {
                status.textContent = 'Impossible de lire cet atlas PNG.';
                console.error('[Custom Skins]', error);
            }
            file.value = '';
        });

        resetButton.addEventListener('click', () => {
            resetSkin();
            preview.src = DEFAULT_SKIN;
            status.textContent = 'Paul.png par défaut sera utilisé.';
        });

        actions.append(importButton, resetButton);
        content.append(heading, description, file, actions, status);
        panel.append(preview, content);
        container.appendChild(panel);
    }

    // Pont public minimal pour les mods multijoueurs : le skin reste local,
    // Multiplayer Test ne peut que lire l’atlas actif pour l’envoyer au pair.
    window.LaPlaineCustomSkins = Object.freeze({
        getCurrentSkinDataUrl() { return activeSkin || null; },
        hasCustomSkin() { return Boolean(activeSkin); }
    });

    installInMemoryReplacement();

    if (!window.LaPlaineAPI || typeof window.LaPlaineAPI.registerMenuCategory !== 'function') {
        console.error('[Custom Skins] API de menu La Plaine indisponible.');
        return;
    }

    window.LaPlaineAPI.registerMenuCategory({
        id: 'custom-skins',
        title: 'Skins',
        description: 'Personnalisation du personnage',
        render: buildPanel
    });
    console.info('[Custom Skins] Mod chargé — remplacement mémoire de Paul.png actif.');
})();
