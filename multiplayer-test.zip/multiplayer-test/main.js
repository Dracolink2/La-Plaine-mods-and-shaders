/* ============================================================
 * LA PLAINE MULTIPLAYER
 * Core version: 0.4.0
 * Protocol: 3
 * Compatible cible: La Plaine 0.2.7.0
 *
 * Architecture:
 *  - WebRTC P2P
 *  - Host / Client
 *  - Synchronisation des joueurs
 *  - Synchronisation des blocs
 *  - Synchronisation du monde
 *  - Synchronisation des créatures
 *  - Chat multijoueur
 *  - Profils et pseudos persistants
 *  - Gestion des connexions
 *  - Gestion des erreurs
 *  - API publique pour les add-ons
 *  - Protocole versionné
 *
 * IMPORTANT:
 *  Le transport est P2P. Aucun serveur de relais (TURN)
 *  n'est fourni par ce fichier.
 * ============================================================ */

(() => {
    'use strict';

    if (window.__laPlaineMultiplayerLoaded) return;
    window.__laPlaineMultiplayerLoaded = true;

    // ========================================================
    // CONFIGURATION
    // ========================================================

    const CONFIG = Object.freeze({
        id: 'la-plaine-multiplayer',

        version: '2.0.0',
        protocol: 3,

        maxPlayers: 30,

        playerInterval: 50,
        worldInterval: 1000,
        mobInterval: 250,

        blockInterval: 100,
        saveInterval: 3000,

        disconnectTimeout: 8000,

        maxPacketSize: 180000,
        maxChatLength: 240,

        maxBlockBatch: 50,

        maxSnapshotQueue: 10000,

        stunServers: [
            { urls: 'stun:stun.l.google.com:19302' }
        ],

        nicknameKey: 'laPlaine.multiplayer.nickname',
        playerIdKey: 'laPlaine.multiplayer.playerId',

        defaultNickname: 'Joueur'
    });

    const STORAGE = {
        role: 'laPlaine.multiplayer.role',
        offer: 'laPlaine.multiplayer.joinOffer',
        nickname: CONFIG.nicknameKey
    };

    // ========================================================
    // UTILITAIRES
    // ========================================================

    const Utils = {
        id() {
            try {
                return crypto.randomUUID();
            } catch {
                return 'lp-' + Math.random().toString(36).slice(2)
                    + Date.now().toString(36);
            }
        },

        number(value, fallback = 0) {
            const n = Number(value);
            return Number.isFinite(n) ? n : fallback;
        },

        clamp(value, min, max) {
            return Math.max(min, Math.min(max, value));
        },

        text(value, max = 64) {
            return String(value ?? '')
                .replace(/[\u0000-\u001f\u007f]/g, '')
                .trim()
                .slice(0, max);
        },

        storageGet(key, fallback = null) {
            try {
                return localStorage.getItem(key) ?? fallback;
            } catch {
                return fallback;
            }
        },

        storageSet(key, value) {
            try {
                localStorage.setItem(key, String(value));
                return true;
            } catch {
                return false;
            }
        },

        sessionGet(key, fallback = null) {
            try {
                return sessionStorage.getItem(key) ?? fallback;
            } catch {
                return fallback;
            }
        },

        sessionSet(key, value) {
            try {
                sessionStorage.setItem(key, String(value));
                return true;
            } catch {
                return false;
            }
        },

        emit(name, detail = {}) {
            window.dispatchEvent(
                new CustomEvent('laplaine:multiplayer:' + name, {
                    detail
                })
            );
        }
    };

    // ========================================================
    // IDENTITÉ DU JOUEUR
    // ========================================================

    const Identity = {
        id: null,
        nickname: null,

        init() {
            this.id = Utils.storageGet(CONFIG.playerIdKey);

            if (!this.id) {
                this.id = Utils.id();
                Utils.storageSet(CONFIG.playerIdKey, this.id);
            }

            this.nickname = this.validate(
                Utils.storageGet(STORAGE.nickname, CONFIG.defaultNickname)
            );
        },

        validate(value) {
            let name = Utils.text(value, 24);

            name = name.replace(/[<>]/g, '');

            if (!name) name = CONFIG.defaultNickname;

            return name;
        },

        setNickname(value) {
            this.nickname = this.validate(value);

            Utils.storageSet(STORAGE.nickname, this.nickname);

            Utils.emit('nickname-changed', {
                nickname: this.nickname
            });

            return this.nickname;
        }
    };

    Identity.init();

    // ========================================================
    // ÉVÉNEMENTS ET API ADD-ONS
    // ========================================================

    const Addons = {
        handlers: new Map(),
        packetHandlers: new Map(),
        registered: new Map(),

        register(id, metadata = {}) {
            id = Utils.text(id, 48);

            if (!/^[a-z0-9_-]+$/i.test(id)) {
                throw new Error('Identifiant add-on invalide.');
            }

            if (this.registered.has(id)) {
                throw new Error('Add-on déjà enregistré : ' + id);
            }

            this.registered.set(id, {
                id,
                version: Utils.text(metadata.version || '1.0.0', 24),
                name: Utils.text(metadata.name || id, 64)
            });

            return {
                id,

                on: (event, callback) =>
                    this.on(id, event, callback),

                send: (type, data) =>
                    Network.sendAddon(id, type, data),

                remove: () =>
                    this.unregister(id)
            };
        },

        unregister(id) {
            this.registered.delete(id);

            for (const [event, entries] of this.handlers) {
                this.handlers.set(
                    event,
                    entries.filter(entry => entry.id !== id)
                );
            }

            for (const [type, entries] of this.packetHandlers) {
                this.packetHandlers.set(
                    type,
                    entries.filter(entry => entry.id !== id)
                );
            }
        },

        on(id, event, callback) {
            if (typeof callback !== 'function') return;

            if (!this.handlers.has(event)) {
                this.handlers.set(event, []);
            }

            this.handlers.get(event).push({ id, callback });
        },

        onPacket(id, type, callback) {
            if (typeof callback !== 'function') return;

            if (!this.packetHandlers.has(type)) {
                this.packetHandlers.set(type, []);
            }

            this.packetHandlers.get(type).push({ id, callback });
        },

        emit(event, data) {
            for (const entry of this.handlers.get(event) || []) {
                try {
                    entry.callback(data);
                } catch (error) {
                    console.error(
                        '[Multiplayer] Add-on error:',
                        entry.id,
                        error
                    );
                }
            }
        },

        receiveAddon(packet) {
            const entries = this.packetHandlers.get(packet.addonType) || [];

            for (const entry of entries) {
                try {
                    entry.callback(packet.data);
                } catch (error) {
                    console.error('[Multiplayer] Add-on packet error:', error);
                }
            }

            this.emit('addon:packet', packet);
        }
    };

    // ========================================================
    // ÉTAT CENTRAL
    // ========================================================

    const State = {
        role: 'solo',

        world: null,
        player: null,

        peer: null,
        channel: null,
        peers: new Map(),
        channels: new Map(),

        connected: false,
        authenticated: false,

        remote: null,
        remoteId: null,
        remoteIds: new Set(),

        remotePlayers: new Map(),

        lastRemoteAt: 0,

        remoteSeedMatches: null,

        blockQueue: new Map(),
        snapshotQueue: [],

        applyingRemoteBlock: false,
        applyingRemoteMeta: false,
        applyingRemoteMob: false,

        localWorldId: null,

        timer: null,

        started: false,

        nickname: Identity.nickname,

        stats: {
            sent: 0,
            received: 0,
            invalid: 0,
            reconnects: 0
        },

        lastPlayerSync: 0,
        lastWorldSync: 0,
        lastMobSync: 0,
        lastBlockSync: 0,
        lastSave: 0
    };

    // ========================================================
    // PROTOCOLE RÉSEAU
    // ========================================================

    const Network = {
        send(packet, exceptChannel = null, onlyChannel = null) {
            const message = {
                protocol: CONFIG.protocol,
                timestamp: Date.now(),
                sender: Identity.id,
                ...packet
            };

            try {
                const data = JSON.stringify(message);

                if (data.length > CONFIG.maxPacketSize) {
                    console.warn('[Multiplayer] Paquet trop volumineux.');
                    return false;
                }

                let sent = false;
                for (const channel of State.channels.values()) {
                    if (onlyChannel && channel !== onlyChannel) continue;
                    if (channel === exceptChannel || channel.readyState !== 'open' || channel.bufferedAmount > 1000000) continue;
                    channel.send(data); sent = true; State.stats.sent++;
                }
                return sent;

            } catch (error) {
                console.warn('[Multiplayer] Erreur réseau:', error);
                return false;
            }
        },

        receive(raw, fromChannel = null) {
            if (typeof raw !== 'string') return;

            if (raw.length > CONFIG.maxPacketSize) {
                State.stats.invalid++;
                return;
            }

            let packet;

            try {
                packet = JSON.parse(raw);
            } catch {
                State.stats.invalid++;
                return;
            }

            if (!packet || typeof packet.type !== 'string') return;

            if (packet.protocol !== CONFIG.protocol) {
                Utils.emit('protocol-mismatch', packet);
                return;
            }

            if (packet.sender === Identity.id) return;

            if ((!State.authenticated || (State.role === 'host' && !State.remoteIds.has(packet.sender))) && packet.type !== 'hello') {
                return;
            }

            State.stats.received++;

            Utils.emit('packet', packet);
            if (State.role === 'host' && packet.type !== 'hello' && packet.type !== 'disconnect') this.send(packet, fromChannel);

            this.dispatch(packet);
        },

        dispatch(packet) {
            switch (packet.type) {

                case 'hello':
                    Session.receiveHello(packet);
                    break;

                case 'player':
                    Players.receive(packet);
                    break;

                case 'blocks':
                    WorldSync.receiveBlocks(packet);
                    break;

                case 'world-meta':
                    WorldSync.receiveMetadata(packet);
                    break;

                case 'world-request':
                    WorldSync.sendSnapshot();
                    break;

                case 'world-snapshot-start':
                    Utils.emit('snapshot-start', packet);
                    break;

                case 'world-snapshot-end':
                    Utils.emit('snapshot-end', packet);
                    break;

                case 'mobs':
                    Mobs.receive(packet);
                    break;

                case 'chat':
                    Chat.receive(packet);
                    break;

                case 'ping':
                    this.send({ type: 'pong', id: packet.id });
                    break;

                case 'pong':
                    Utils.emit('pong', packet);
                    break;

                case 'disconnect':
                    Utils.emit('remote-disconnect', packet);
                    break;

                case 'addon':
                    Addons.receiveAddon(packet);
                    break;

                default:
                    Addons.emit('unknown-packet', packet);
                    break;
            }
        },

        sendAddon(addonId, type, data) {
            if (!Addons.registered.has(addonId)) return false;

            return this.send({
                type: 'addon',
                addonId,
                addonType: Utils.text(type, 64),
                data
            });
        }
    };

    // ========================================================
    // SESSION ET CONNEXION
    // ========================================================

    const Session = {
        receiveHello(packet) {
            if (typeof packet.playerId !== 'string') return;

            if (packet.playerId === Identity.id) return;

            if (!State.remoteIds.has(packet.playerId) && State.remoteIds.size >= CONFIG.maxPlayers - 1) return;

            if (packet.protocol !== CONFIG.protocol) return;

            if (State.world && packet.seed !== undefined) {
                State.remoteSeedMatches =
                    String(packet.seed) === String(State.world.seed);
            }

            State.remoteId = packet.playerId;
            State.remoteIds.add(packet.playerId);
            State.authenticated = true;

            Utils.emit('player-joined', {
                id: packet.playerId,
                nickname: Utils.text(packet.nickname, 24)
            });

            if (State.role === 'host') {
                WorldSync.sendSnapshot();
            }

            UI.updateStatus('Connecté avec ' +
                Utils.text(packet.nickname, 24), 'ok');
        },

        hello(channel = null) {
            Network.send({
                type: 'hello',
                playerId: Identity.id,
                nickname: Identity.nickname,
                role: State.role,
                seed: String(State.world?.seed ?? ''),
                worldVersion: CONFIG.version
            }, null, channel);
        },

        disconnect() {
            try {
                Network.send({
                    type: 'disconnect',
                    reason: 'left'
                });
            } catch (_) {}

            State.connected = false;
            State.authenticated = false;
            for (const channel of State.channels.values()) { try { channel.close(); } catch (_) {} }
            for (const peer of State.peers.values()) { try { peer.close(); } catch (_) {} }
            State.channels.clear(); State.peers.clear(); State.remoteIds.clear();
            State.channel = null;
            State.peer = null;

            State.snapshotQueue.length = 0;

            Utils.emit('disconnected');
        }
    };

    // ========================================================
    // WEBRTC
    // ========================================================

    const Transport = {
        create(connectionId = Utils.id()) {
            if (!window.RTCPeerConnection) {
                throw new Error('WebRTC non disponible.');
            }

            const peer = new RTCPeerConnection({
                iceServers: CONFIG.stunServers
            });

            State.peer = peer;
            State.peers.set(connectionId, peer);

            peer.onconnectionstatechange = () => {
                const status = peer.connectionState;

                if (status === 'connected') {
                    State.connected = true;
                    UI.updateStatus('Connexion établie.', 'ok');
                }

                if (status === 'failed') {
                    State.connected = [...State.channels.values()].some(channel => channel.readyState === 'open');
                    if (State.role !== 'host' && !State.connected) State.authenticated = false;
                    UI.updateStatus(
                        'Connexion impossible. Un relais TURN peut être nécessaire.',
                        'error'
                    );
                }

                if (status === 'disconnected') {
                    State.connected = [...State.channels.values()].some(channel => channel.readyState === 'open');
                    UI.updateStatus('Connexion interrompue.', 'warn');
                }

                Utils.emit('connection-state', status);
            };

            peer.ondatachannel = event => {
                this.bind(event.channel, connectionId);
            };

            return peer;
        },

        bind(channel, connectionId) {
            State.channel = channel;
            State.channels.set(connectionId, channel);

            channel.binaryType = 'arraybuffer';

            channel.onopen = () => {
                State.connected = true;

                Session.hello(channel);

                if (State.role === 'join') {
                    Network.send({ type: 'world-request' });
                }

                Utils.emit('connected');

                UI.updateStatus('Synchronisation en cours...', 'ok');
            };

            channel.onmessage = event => {
                Network.receive(event.data, channel);
            };

            channel.onclose = () => {
                State.channels.delete(connectionId);
                State.peers.delete(connectionId);
                State.connected = [...State.channels.values()].some(item => item.readyState === 'open');
                if (State.role !== 'host' && !State.connected) State.authenticated = false;

                UI.updateStatus('Connexion fermée.', 'warn');

                Utils.emit('disconnected');
            };

            channel.onerror = error => {
                console.error('[Multiplayer] DataChannel:', error);
            };
        },

        waitForICE(peer) {
            if (peer.iceGatheringState === 'complete') {
                return Promise.resolve();
            }

            return new Promise(resolve => {
                const timeout = setTimeout(resolve, 15000);

                const check = () => {
                    if (peer.iceGatheringState === 'complete') {
                        clearTimeout(timeout);
                        peer.removeEventListener(
                            'icegatheringstatechange',
                            check
                        );
                        resolve();
                    }
                };

                peer.addEventListener(
                    'icegatheringstatechange',
                    check
                );
            });
        },

        encode(value) {
            return btoa(
                String.fromCharCode(
                    ...new TextEncoder().encode(JSON.stringify(value))
                )
            ).replace(/\+/g, '-')
                .replace(/\//g, '_')
                .replace(/=+$/g, '');
        },

        decode(value) {
            const raw = String(value || '')
                .trim()
                .replace(/-/g, '+')
                .replace(/_/g, '/');

            if (!raw || raw.length > 4000000) {
                throw new Error('Code de connexion invalide.');
            }

            const binary = atob(
                raw + '='.repeat((4 - raw.length % 4) % 4)
            );

            const bytes = Uint8Array.from(
                binary,
                char => char.charCodeAt(0)
            );

            const result = JSON.parse(
                new TextDecoder().decode(bytes)
            );

            if (
                !result ||
                !result.description ||
                !result.description.sdp ||
                !result.description.type
            ) {
                throw new Error('Description WebRTC invalide.');
            }

            return result;
        },

        async createHostOffer() {
            if (State.peers.size >= CONFIG.maxPlayers - 1) throw new Error('La partie a atteint sa limite de joueurs.');
            const connectionId = Utils.id();
            const peer = this.create(connectionId);

            const channel = peer.createDataChannel(
                'la-plaine-multiplayer',
                { ordered: true }
            );

            this.bind(channel, connectionId);

            await peer.setLocalDescription(
                await peer.createOffer()
            );

            await this.waitForICE(peer);

            return this.encode({
                protocol: CONFIG.protocol,
                connectionId,
                description: peer.localDescription,
                seed: String(State.world.seed ?? '')
            });
        },

        async acceptHostAnswer(code) {
            const data = this.decode(code);

            if (data.description.type !== 'answer') {
                throw new Error('Une réponse client est attendue.');
            }

            const peer = State.peers.get(data.connectionId);
            if (!peer) throw new Error('Invitation correspondante introuvable. Crée une nouvelle invitation.');
            await peer.setRemoteDescription(
                new RTCSessionDescription(data.description)
            );
        },

        async createJoinAnswer(code) {
            const data = this.decode(code);

            if (data.description.type !== 'offer') {
                throw new Error('Une offre de connexion est attendue.');
            }

            const connectionId = data.connectionId;
            if (typeof connectionId !== 'string') throw new Error('Invitation incompatible.');
            const peer = this.create(connectionId);

            await peer.setRemoteDescription(
                new RTCSessionDescription(data.description)
            );

            await peer.setLocalDescription(
                await peer.createAnswer()
            );

            await this.waitForICE(peer);

            return this.encode({
                protocol: CONFIG.protocol,
                connectionId,
                description: peer.localDescription,
                seed: String(State.world.seed ?? '')
            });
        }
    };

    // ========================================================
    // JOUEURS DISTANTS
    // ========================================================

    const Players = {
        receive(packet) {
            if (!packet.player || typeof packet.player !== 'object') return;

            const p = packet.player;

            const coordinates = [p.x, p.y, p.z, p.rotation];

            if (!coordinates.every(v => Number.isFinite(Number(v)))) {
                return;
            }

            const id = String(packet.playerId || '');

            if (!id || id.length > 100) return;

            const snapshot = {
                id,
                nickname: Utils.text(packet.nickname, 24),
                dimension: Utils.text(packet.dimension, 64),
                skin: /^Paul(?:[1-9]|10)\.png$/.test(packet.skin) ? packet.skin : 'Paul1.png',
                x: Number(p.x),
                y: Number(p.y),
                z: Number(p.z),
                rotation: Number(p.rotation),
                health: Utils.clamp(Number(p.health) || 0, 0, 100),
                velocity: {
                    x: Utils.number(p.velocityX),
                    y: Utils.number(p.velocityY),
                    z: Utils.number(p.velocityZ)
                },
                inventory: this.validateInventory(p.inventory),
                receivedAt: Date.now()
            };

            snapshot.avatar = State.remotePlayers.get(id)?.avatar || null;
            State.remotePlayers.set(id, snapshot);
            State.remoteSnapshot = snapshot;
            State.lastRemoteAt = Date.now();

            this.updateAvatar(snapshot);

            Utils.emit('player-updated', snapshot);
        },

        validateInventory(inventory) {
            if (!Array.isArray(inventory) || inventory.length !== 36) {
                return [];
            }

            return inventory.map(slot => ({
                type: Utils.clamp(
                    Math.floor(Utils.number(slot?.type)),
                    0,
                    255
                ),
                count: Utils.clamp(
                    Math.floor(Utils.number(slot?.count)),
                    0,
                    100
                )
            }));
        },

        send() {
            if (!State.player?.serializeState) return;

            const p = State.player.serializeState();

            Network.send({
                type: 'player',
                playerId: Identity.id,
                nickname: Identity.nickname,

                dimension: State.world.currentDimensionId || 'overworld',
                skin: /^Paul(?:[1-9]|10)\.png$/.test(State.player.selectedSkin) ? State.player.selectedSkin : 'Paul1.png',

                player: {
                    x: Utils.number(p.x),
                    y: Utils.number(p.y),
                    z: Utils.number(p.z),

                    rotation: Utils.number(p.rot_y),

                    health: Utils.number(p.health),

                    velocityX: Utils.number(p.velocity_x),
                    velocityY: Utils.number(p.velocity_y),
                    velocityZ: Utils.number(p.velocity_z),

                    inventory: this.validateInventory(p.inventory)
                }
            });
        },

        updateAvatar(snapshot) {
            const world = State.world;

            if (!world?.scene || !window.THREE) return;

            if (!State.remotePlayers.get(snapshot.id)?.avatar) {
                const THREE = window.THREE;

                const group = new THREE.Group();

                world.scene.add(group);

                snapshot.avatar = group;
                State.remotePlayers.set(snapshot.id, snapshot);
            }

            const avatar = State.remotePlayers.get(snapshot.id)?.avatar;

            if (!avatar) return;

            if (avatar.userData.skin !== snapshot.skin) {
                const skinName = /^Paul(?:[1-9]|10)\.png$/.test(snapshot.skin) ? snapshot.skin : 'Paul1.png';
                avatar.userData.skin = skinName;
                const image = new Image();
                image.onload = () => {
                    if (avatar.userData.skin !== skinName) return;
                    while (avatar.children.length) {
                        const old = avatar.children[0]; avatar.remove(old);
                        old.geometry?.dispose?.();
                        for (const material of (Array.isArray(old.material) ? old.material : [old.material])) { material?.map?.dispose?.(); material?.dispose?.(); }
                    }
                    const make = (geometry, pos, uv) => {
                        const mesh = new THREE.Mesh(geometry, State.player.createBoxMaterials(image, ...uv));
                        mesh.position.set(...pos); avatar.add(mesh);
                    };
                    make(new THREE.BoxGeometry(.24,.75,.24), [.12,.375,0], [0,16,4,12,4]);
                    make(new THREE.BoxGeometry(.24,.75,.24), [-.12,.375,0], [16,48,4,12,4]);
                    make(new THREE.BoxGeometry(.48,.75,.24), [0,1.125,0], [16,16,8,12,4]);
                    make(new THREE.BoxGeometry(.24,.75,.24), [.36,1.125,0], [40,16,4,12,4]);
                    make(new THREE.BoxGeometry(.24,.75,.24), [-.36,1.125,0], [32,48,4,12,4]);
                    make(new THREE.BoxGeometry(.4,.4,.4), [0,1.7,0], [0,0,8,8,8]);
                };
                image.src = `/static/textures/skins/${encodeURIComponent(skinName)}`;
            }

            avatar.position.set(
                snapshot.x,
                snapshot.y,
                snapshot.z
            );

            avatar.rotation.y = snapshot.rotation;

            avatar.visible =
                snapshot.dimension ===
                (world.currentDimensionId || 'overworld');
        }
    };

    // ========================================================
    // MONDE ET BLOCS
    // ========================================================

    const WorldSync = {
        receiveBlocks(packet) {
            if (!Array.isArray(packet.changes)) return;

            if (State.remoteSeedMatches !== true) return;

            const rebuild = new Set();

            State.applyingRemoteBlock = true;

            try {
                for (const change of packet.changes.slice(
                    0,
                    CONFIG.maxBlockBatch
                )) {
                    const x = Math.floor(Number(change.x));
                    const y = Math.floor(Number(change.y));
                    const z = Math.floor(Number(change.z));
                    const id = Math.floor(Number(change.id));

                    if (![x, y, z, id].every(Number.isFinite)) continue;

                    if (y < 0 || y >= 256 || id < 0 || id > 255) {
                        continue;
                    }

                    const dimension = String(
                        change.dimension || 'overworld'
                    );

                    if (
                        dimension !==
                        (State.world.currentDimensionId || 'overworld')
                    ) {
                        continue;
                    }

                    State.world.setBlock(x, y, z, id);

                    rebuild.add(`${x},${z}`);
                }

                for (const key of rebuild) {
                    const [x, z] = key.split(',').map(Number);

                    State.world.rebuildAround?.(x, z);
                }

            } finally {
                State.applyingRemoteBlock = false;
            }
        },

        collectChanges() {
            const result = new Map();

            const persisted = State.world?.persistedChanges;

            if (!(persisted instanceof Map)) return [];

            for (const [dimension, chunks] of persisted) {
                if (!(chunks instanceof Map)) continue;

                for (const blocks of chunks.values()) {
                    if (!(blocks instanceof Map)) continue;

                    for (const change of blocks.values()) {
                        if (!change) continue;

                        const key = [
                            dimension,
                            change.x,
                            change.y,
                            change.z
                        ].join('|');

                        result.set(key, {
                            dimension,
                            x: change.x,
                            y: change.y,
                            z: change.z,
                            id: change.id
                        });
                    }
                }
            }

            return [...result.values()];
        },

        sendSnapshot() {
            if (State.role !== 'host') return;

            const changes = this.collectChanges();

            Network.send({
                type: 'world-snapshot-start',
                count: changes.length
            });

            for (
                let i = 0;
                i < changes.length;
                i += CONFIG.maxBlockBatch
            ) {
                State.snapshotQueue.push({
                    type: 'blocks',
                    changes: changes.slice(
                        i,
                        i + CONFIG.maxBlockBatch
                    )
                });
            }

            State.snapshotQueue.push({
                type: 'world-snapshot-end',
                count: changes.length
            });

            this.sendMetadata();
        },

        sendMetadata() {
            if (State.role !== 'host') return;

            Network.send({
                type: 'world-meta',

                seed: String(State.world.seed ?? ''),

                dimension: String(
                    State.world.currentDimensionId || 'overworld'
                ),

                dayTime: Utils.number(State.world.dayTime),

                dayDuration: Utils.number(
                    State.world.dayDuration,
                    240
                )
            });
        },

        receiveMetadata(packet) {
            if (State.role !== 'join') return;

            if (
                String(packet.seed) !== String(State.world.seed)
            ) {
                State.remoteSeedMatches = false;

                UI.updateStatus(
                    'Attention : les seeds sont différentes.',
                    'warn'
                );

                return;
            }

            State.remoteSeedMatches = true;

            State.applyingRemoteMeta = true;

            try {
                if (Number.isFinite(Number(packet.dayTime))) {
                    State.world.dayTime = Number(packet.dayTime);
                }

                if (
                    Number.isFinite(Number(packet.dayDuration)) &&
                    Number(packet.dayDuration) > 0
                ) {
                    State.world.dayDuration =
                        Number(packet.dayDuration);
                }

                const dimension = String(
                    packet.dimension || 'overworld'
                );

                if (
                    dimension !== State.world.currentDimensionId &&
                    window.dimensionRegistry?.get?.(dimension)
                ) {
                    window.dimensionRegistry.switchTo(
                        State.world,
                        State.player,
                        dimension
                    );
                }

            } finally {
                State.applyingRemoteMeta = false;
            }
        },

        pump() {
            if (!State.snapshotQueue.length) return;

            const openChannels = [...State.channels.values()].filter(channel => channel.readyState === 'open' && channel.bufferedAmount <= 350000);
            if (!openChannels.length) return;

            let count = 0;

            while (
                State.snapshotQueue.length &&
                count < 3
            ) {
                if (!Network.send(State.snapshotQueue[0])) break;

                State.snapshotQueue.shift();
                count++;
            }
        }
    };

    // ========================================================
    // INTERCEPTION DES BLOCS
    // ========================================================

    function installBlockHooks() {
        const world = State.world;

        if (!world || world.__lpMultiplayerBlockHook) return;

        if (typeof world.setBlock !== 'function') return;

        const original = world.setBlock.bind(world);

        world.setBlock = function (x, y, z, id) {
            const bx = Math.floor(Number(x));
            const by = Math.floor(Number(y));
            const bz = Math.floor(Number(z));

            const before = this.getBlockI?.(bx, by, bz);

            const result = original(x, y, z, id);

            const after = this.getBlockI?.(bx, by, bz);

            if (
                !State.applyingRemoteBlock &&
                !this.generating &&
                before !== after &&
                State.connected &&
                State.authenticated
            ) {
                const dimension = String(
                    this.currentDimensionId || 'overworld'
                );

                const key = `${dimension}|${bx}|${by}|${bz}`;

                State.blockQueue.set(key, {
                    dimension,
                    x: bx,
                    y: by,
                    z: bz,
                    id: Utils.clamp(Math.floor(Number(id)), 0, 255)
                });
            }

            return result;
        };

        world.__lpMultiplayerBlockHook = true;
    }

    function sendBlockQueue() {
        if (!State.blockQueue.size) return;

        if (!State.connected || !State.authenticated) return;

        const changes = [
            ...State.blockQueue.values()
        ].slice(0, CONFIG.maxBlockBatch);

        if (Network.send({
            type: 'blocks',
            changes
        })) {
            for (const change of changes) {
                State.blockQueue.delete(
                    `${change.dimension}|${change.x}|${change.y}|${change.z}`
                );
            }
        }
    }

    // ========================================================
    // CRÉATURES
    // ========================================================

    const Mobs = {
        send() {
            if (State.role !== 'host') return;

            const manager = State.world?.mobManager;

            if (!manager?.mobs) return;

            const mobs = [];

            for (const mob of manager.mobs) {
                if (!mob || mob.dead || !mob.position) continue;

                if (!mob.__lpMultiplayerId) {
                    mob.__lpMultiplayerId = Utils.id();
                }

                mobs.push({
                    id: mob.__lpMultiplayerId,

                    kind: String(mob.definition?.id || ''),

                    x: Utils.number(mob.position.x),
                    y: Utils.number(mob.position.y),
                    z: Utils.number(mob.position.z),

                    direction: Utils.number(mob.direction),
                    health: Utils.number(mob.health)
                });
            }

            Network.send({
                type: 'mobs',
                mobs: mobs.slice(0, 80)
            });
        },

        receive(packet) {
            if (State.role !== 'join') return;

            const manager = State.world?.mobManager;
            const Constructor = window.MobEntity;

            if (!manager || !Constructor) return;

            if (!Array.isArray(packet.mobs)) return;

            const definitions =
                window.mobRegistry?.getAll?.() || [];

            State.applyingRemoteMob = true;

            try {
                const incoming = new Set();

                for (const entry of packet.mobs.slice(0, 80)) {
                    if (!entry || !entry.id || !entry.kind) continue;

                    incoming.add(entry.id);

                    let mob = [...manager.mobs].find(
                        item => item.__lpMultiplayerId === entry.id
                    );

                    if (!mob) {
                        const definition = definitions.find(
                            item => String(item.id) === entry.kind
                        );

                        if (!definition) continue;

                        mob = new Constructor(
                            definition,
                            State.world,
                            State.world.scene,
                            Number(entry.x),
                            Number(entry.y),
                            Number(entry.z)
                        );

                        mob.__lpMultiplayerId = entry.id;

                        manager.mobs.add(mob);
                    }

                    mob.position.set(
                        Number(entry.x),
                        Number(entry.y),
                        Number(entry.z)
                    );

                    mob.direction = Number(entry.direction) || 0;
                    mob.health = Number(entry.health) || 0;

                    const offset = mob.definition?.model?.yOffset || 0;

                    mob.group?.position.set(
                        mob.position.x,
                        mob.position.y + offset,
                        mob.position.z
                    );
                }

                for (const mob of [...manager.mobs]) {
                    if (
                        mob.__lpMultiplayerId &&
                        !incoming.has(mob.__lpMultiplayerId)
                    ) {
                        try {
                            mob.die();
                        } catch (_) {}

                        manager.mobs.delete(mob);
                    }
                }

            } finally {
                State.applyingRemoteMob = false;
            }
        }
    };

    // ========================================================
    // CHAT
    // ========================================================

    const Chat = {
        send(message) {
            const text = Utils.text(
                message,
                CONFIG.maxChatLength
            );

            if (!text) return false;

            const packet = {
                type: 'chat',
                nickname: Identity.nickname,
                message: text
            };

            this.display(packet);

            return Network.send(packet);
        },

        receive(packet) {
            this.display({
                nickname: Utils.text(packet.nickname, 24),
                message: Utils.text(
                    packet.message,
                    CONFIG.maxChatLength
                )
            });
        },

        display(packet) {
            const log = document.getElementById(
                'lp-mp-chat-log'
            );

            if (!log) return;

            const line = document.createElement('div');

            line.textContent =
                `${packet.nickname || 'Joueur'} : ${packet.message}`;

            log.appendChild(line);

            while (log.children.length > 40) {
                log.firstChild.remove();
            }

            log.scrollTop = log.scrollHeight;

            Addons.emit('chat-message', packet);
        }
    };

    // ========================================================
    // INTERFACE
    // ========================================================

    const UI = {
        root: null,
        status: null,

        updateStatus(message, type = 'info') {
            if (!this.status) return;

            this.status.textContent = message;
            this.status.dataset.kind = type;
        },

        button(parent, label, callback) {
            const button = document.createElement('button');

            button.type = 'button';
            button.className = 'btn-menu small';
            button.textContent = label;

            button.addEventListener('click', async () => {
                try {
                    await callback();
                } catch (error) {
                    this.updateStatus(
                        error.message || 'Erreur multijoueur.',
                        'error'
                    );
                }
            });

            parent.appendChild(button);

            return button;
        },

        createPanel() {
            if (this.root) return;

            const root = document.createElement('section');

            root.className = 'lp-mp-panel lp-mp-collapsed';
            root.id = 'lp-mp-panel';

            const header = document.createElement('div');
            header.className = 'lp-mp-header';

            const title = document.createElement('strong');
            title.textContent = 'MP';

            const role = document.createElement('span');
            role.textContent =
                State.role === 'host' ? 'HÔTE' : 'JOUEUR';

            header.append(title, role);

            const status = document.createElement('p');
            status.className = 'lp-mp-status';

            this.status = status;

            // PROFIL

            const profileTitle = document.createElement('h4');
            profileTitle.textContent = 'Profil joueur';

            const nicknameLabel = document.createElement('label');
            nicknameLabel.textContent = 'Ton pseudo';

            const nickname = document.createElement('input');

            nickname.type = 'text';
            nickname.maxLength = 24;
            nickname.value = Identity.nickname;
            nickname.placeholder = 'Ton pseudo...';

            nickname.addEventListener('change', () => {
                nickname.value = Identity.setNickname(
                    nickname.value
                );
            });

            // CONNEXION

            const connectionTitle = document.createElement('h4');
            connectionTitle.textContent = 'Connexion';

            const output = document.createElement('textarea');

            output.readOnly = true;
            output.rows = 4;
            output.placeholder = 'Ton code apparaîtra ici...';

            const input = document.createElement('textarea');

            input.rows = 4;
            input.placeholder = 'Colle ton code ici...';

            const actions = document.createElement('div');
            actions.className = 'lp-mp-actions';

            if (State.role === 'host') {
                this.button(actions, 'CRÉER UNE INVITATION', async () => {
                    output.value = await Transport.createHostOffer();

                    this.updateStatus(
                        'Invitation créée. Envoie le code à un joueur.',
                        'ok'
                    );
                });

                this.button(actions, 'VALIDER LA RÉPONSE', async () => {
                    await Transport.acceptHostAnswer(input.value);

                    this.updateStatus(
                        'Réponse reçue. Connexion en cours...',
                        'ok'
                    );
                });

            } else {
                this.button(actions, 'REJOINDRE', async () => {
                    output.value = await Transport.createJoinAnswer(
                        input.value
                    );

                    this.updateStatus(
                        'Réponse créée ! Envoie-la à l’hôte.',
                        'ok'
                    );
                });
            }

            this.button(actions, 'COPIER LE CODE', async () => {
                if (!output.value) {
                    throw new Error('Aucun code disponible.');
                }

                await navigator.clipboard.writeText(output.value);

                this.updateStatus('Code copié !', 'ok');
            });

            // JOUEURS

            const playersTitle = document.createElement('h4');
            playersTitle.textContent = 'Joueurs connectés';

            const players = document.createElement('div');
            players.id = 'lp-mp-players';

            // CHAT

            const chatTitle = document.createElement('h4');
            chatTitle.textContent = 'Chat';

            const chatLog = document.createElement('div');
            chatLog.id = 'lp-mp-chat-log';
            chatLog.className = 'lp-mp-chat-log';

            const chatForm = document.createElement('form');
            chatForm.className = 'lp-mp-chat';

            const chatInput = document.createElement('input');

            chatInput.type = 'text';
            chatInput.maxLength = CONFIG.maxChatLength;
            chatInput.placeholder = 'Écrire un message...';

            const chatSend = document.createElement('button');

            chatSend.type = 'submit';
            chatSend.textContent = 'Envoyer';

            chatForm.append(chatInput, chatSend);

            chatForm.addEventListener('submit', event => {
                event.preventDefault();

                if (Chat.send(chatInput.value)) {
                    chatInput.value = '';
                }
            });

            // ADD-ONS

            const addonTitle = document.createElement('h4');
            addonTitle.textContent = 'Add-ons Multiplayer';

            const addonList = document.createElement('div');

            const refreshAddons = () => {
                addonList.replaceChildren();

                for (const addon of Addons.registered.values()) {
                    const line = document.createElement('p');

                    line.textContent =
                        `${addon.name} · ${addon.version}`;

                    addonList.appendChild(line);
                }
            };

            Addons.emit('ui-ready', {
                root,
                addonList,
                refresh: refreshAddons
            });

            // FERMETURE

            const close = document.createElement('button');

            close.type = 'button';
            close.textContent = 'OUVRIR';

            close.addEventListener('click', () => {
                root.classList.toggle('lp-mp-collapsed');

                close.textContent =
                    root.classList.contains('lp-mp-collapsed')
                        ? 'OUVRIR'
                        : 'FERMER';
            });

            header.appendChild(close);

            root.append(
                header,
                status,
                profileTitle,
                nicknameLabel,
                nickname,
                connectionTitle,
                input,
                output,
                actions,
                playersTitle,
                players,
                chatTitle,
                chatLog,
                chatForm,
                addonTitle,
                addonList
            );

            document.body.appendChild(root);

            this.root = root;

            this.updateStatus(
                'Multiplayer initialisé.',
                'info'
            );

            refreshAddons();

            Utils.emit('ui-ready', { root });
        }
    };

    // ========================================================
    // MENU DE CRÉATION DU MONDE
    // ========================================================

    function installMenu() {
        const api = window.LaPlaineAPI;

        if (!api?.registerWorldCreationOption) {
            console.error('[Multiplayer] API La Plaine indisponible.');
            return;
        }

        api.registerWorldCreationOption({
            id: 'mp-role',
            label: 'Multijoueur',
            type: 'select',
            defaultValue: 'solo',

            options: [
                { value: 'solo', label: 'Solo' },
                { value: 'host', label: 'Héberger une partie' },
                { value: 'join', label: 'Rejoindre une partie' }
            ]
        });

        const attach = () => {
            const root = document.getElementById(
                'lp-world-creation-options'
            );

            if (!root || document.getElementById('lp-mp-join-box')) {
                return;
            }

            const box = document.createElement('div');

            box.id = 'lp-mp-join-box';
            box.className = 'lp-mp-menu-note';

            const label = document.createElement('label');

            label.textContent = 'Code de connexion';

            const code = document.createElement('textarea');

            code.id = 'lp-mp-join-offer';
            code.rows = 3;

            const nickname = document.createElement('input');

            nickname.type = 'text';
            nickname.maxLength = 24;
            nickname.value = Identity.nickname;

            const nicknameLabel = document.createElement('label');

            nicknameLabel.textContent = 'Ton pseudo';

            nickname.addEventListener('change', () => {
                nickname.value = Identity.setNickname(
                    nickname.value
                );
            });

            const update = () => {
                const role = document.querySelector(
                    '[data-mod-option-id="mp-role"]'
                )?.value || 'solo';

                box.hidden = role !== 'join';

                code.hidden = role !== 'join';
                label.hidden = role !== 'join';
            };

            const role = document.querySelector(
                '[data-mod-option-id="mp-role"]'
            );

            role?.addEventListener('change', update);

            box.append(
                label,
                code,
                nicknameLabel,
                nickname
            );

            root.appendChild(box);

            update();
        };

        attach();

        window.addEventListener(
            'laplaine:menu-ready',
            attach
        );

        document.addEventListener('click', event => {
            if (!event.target.closest?.('#btn-create-world')) {
                return;
            }

            const role = document.querySelector(
                '[data-mod-option-id="mp-role"]'
            )?.value || 'solo';

            Utils.sessionSet(STORAGE.role, role);

            if (role === 'join') {
                const code = document.getElementById(
                    'lp-mp-join-offer'
                )?.value.trim();

                try {
                    const parsed = Transport.decode(code);

                    if (parsed.description.type !== 'offer') {
                        throw new Error('Code d’hébergement invalide.');
                    }

                    Utils.sessionSet(STORAGE.offer, code);

                    const seed = document.getElementById('world-seed');

                    if (seed && parsed.seed) {
                        seed.value = parsed.seed;
                    }

                } catch (error) {
                    event.preventDefault();
                    event.stopImmediatePropagation();

                    const errorBox = document.getElementById(
                        'create-world-error'
                    );

                    if (errorBox) {
                        errorBox.textContent = error.message;
                    }
                }
            }
        }, true);
    }

    // ========================================================
    // AUTORITÉ DU MONDE
    // ========================================================

    function installClientAuthority() {
        const world = State.world;

        if (!world || world.__lpMpAuthority) return;

        if (typeof world.updateMobs === 'function') {
            const original = world.updateMobs.bind(world);

            world.updateMobs = function (...args) {
                if (
                    State.role === 'join' &&
                    State.connected
                ) return;

                return original(...args);
            };
        }

        if (typeof world.updateDayNightCycle === 'function') {
            const original = world.updateDayNightCycle.bind(world);

            world.updateDayNightCycle = function (...args) {
                if (
                    State.role === 'join' &&
                    State.connected
                ) return;

                return original(...args);
            };
        }

        world.__lpMpAuthority = true;
    }

    // ========================================================
    // BOUCLE MULTIJOUEUR
    // ========================================================

    function startLoop() {
        if (State.timer) {
            clearInterval(State.timer);
        }

        State.timer = setInterval(() => {
            if (!State.started) return;

            const now = Date.now();

            if (
                State.connected &&
                State.authenticated
            ) {
                if (
                    now - State.lastPlayerSync >=
                    CONFIG.playerInterval
                ) {
                    Players.send();
                    State.lastPlayerSync = now;
                }

                if (
                    now - State.lastBlockSync >=
                    CONFIG.blockInterval
                ) {
                    sendBlockQueue();
                    State.lastBlockSync = now;
                }

                if (
                    State.role === 'host' &&
                    now - State.lastWorldSync >=
                    CONFIG.worldInterval
                ) {
                    WorldSync.sendMetadata();
                    State.lastWorldSync = now;
                }

                if (
                    State.role === 'host' &&
                    now - State.lastMobSync >=
                    CONFIG.mobInterval
                ) {
                    Mobs.send();
                    State.lastMobSync = now;
                }

                WorldSync.pump();

                if (
                    State.remote &&
                    now - State.lastRemoteAt >
                    CONFIG.disconnectTimeout
                ) {
                    State.remote.visible = false;

                    UI.updateStatus(
                        'Le joueur distant ne répond plus.',
                        'warn'
                    );
                }
            }

            if (
                State.world &&
                State.player &&
                now - State.lastSave >= CONFIG.saveInterval
            ) {
                State.lastSave = now;

                try {
                    const key =
                        `laPlaine.multiplayer.${State.world.worldId || 'world'}.local`;

                    Utils.storageSet(
                        key,
                        JSON.stringify({
                            playerId: Identity.id,
                            nickname: Identity.nickname,
                            role: State.role,
                            savedAt: now,
                            state: State.player.serializeState()
                        })
                    );
                } catch (error) {
                    console.warn('[Multiplayer] Sauvegarde impossible.', error);
                }
            }

            Addons.emit('tick', {
                time: now,
                connected: State.connected,
                role: State.role
            });

        }, 50);
    }

    // ========================================================
    // INITIALISATION DU MONDE
    // ========================================================

    function startGame({ world, player }) {
        if (!world || !player) return;

        let role = Utils.sessionGet(STORAGE.role, 'solo');

        if (!['solo', 'host', 'join'].includes(role)) {
            role = 'solo';
        }

        if (role === 'solo') return;

        State.role = role;

        State.world = world;
        State.player = player;

        State.localWorldId = String(
            world.worldId || 'world'
        );

        State.started = true;

        installBlockHooks();
        installClientAuthority();

        UI.createPanel();

        startLoop();

        if (role === 'join') {
            const offer = Utils.sessionGet(STORAGE.offer);

            if (offer) {
                UI.updateStatus(
                    'Préparation de la connexion...',
                    'info'
                );

                Transport.createJoinAnswer(offer)
                    .then(code => {
                        const output = UI.root?.querySelector(
                            'textarea[readonly]'
                        );

                        if (output) output.value = code;

                        Utils.sessionSet(
                            STORAGE.offer,
                            ''
                        );

                        UI.updateStatus(
                            'Réponse créée ! Envoie-la à l’hôte.',
                            'ok'
                        );
                    })
                    .catch(error => {
                        UI.updateStatus(
                            error.message,
                            'error'
                        );
                    });
            }
        } else {
            UI.updateStatus(
                'Tu es l’hôte. Crée une offre pour inviter un joueur.',
                'info'
            );
        }

        Utils.emit('game-start', {
            world,
            player,
            role
        });
    }

    // ========================================================
    // NETTOYAGE
    // ========================================================

    function shutdown() {
        State.started = false;

        if (State.timer) {
            clearInterval(State.timer);
            State.timer = null;
        }

        Session.disconnect();

        if (State.remote?.parent) {
            State.remote.parent.remove(State.remote);
        }

        State.remote = null;

        Utils.emit('game-stop');
    }

    // ========================================================
    // API PUBLIQUE
    // ========================================================

    window.LaPlaineMultiplayer = Object.freeze({

        version: CONFIG.version,

        protocol: CONFIG.protocol,

        identity: {
            get id() {
                return Identity.id;
            },

            get nickname() {
                return Identity.nickname;
            },

            setNickname(value) {
                return Identity.setNickname(value);
            }
        },

        getState() {
            return {
                role: State.role,
                connected: State.connected,
                authenticated: State.authenticated,
                players: State.remotePlayers.size,
                nickname: Identity.nickname,
                stats: { ...State.stats }
            };
        },

        registerAddon(id, metadata) {
            return Addons.register(id, metadata);
        },

        onAddonPacket(id, type, callback) {
            Addons.onPacket(id, type, callback);
        },

        send(packet) {
            return Network.send(packet);
        },

        sendChat(message) {
            return Chat.send(message);
        },

        disconnect() {
            Session.disconnect();
        },

        on(event, callback) {
            Addons.on('external', event, callback);
        }
    });

    // ========================================================
    // STYLES
    // ========================================================

    function installStyles() {
        if (document.getElementById('lp-mp-styles')) return;

        const style = document.createElement('style');

        style.id = 'lp-mp-styles';

        style.textContent = `
            .lp-mp-panel {
                position: fixed;
                z-index: 10050;
                right: 14px;
                bottom: 14px;
                width: min(320px, calc(100vw - 20px));
                max-height: calc(100vh - 28px);
                overflow-y: auto;
                padding: 10px;
                background: rgba(17,22,29,.97);
                color: #f4f6fa;
                border: 1px solid #687789;
                border-radius: 12px;
                box-shadow: 0 8px 35px #0009;
                font: 13px/1.4 Arial, sans-serif;
                box-sizing: border-box;
            }

            .lp-mp-panel * {
                box-sizing: border-box;
            }

            .lp-mp-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 8px;
            }

            .lp-mp-header strong {
                font-size: 16px;
            }

            .lp-mp-panel h4 {
                margin: 14px 0 7px;
                border-bottom: 1px solid #455365;
                padding-bottom: 5px;
            }

            .lp-mp-panel input,
            .lp-mp-panel textarea {
                width: 100%;
                padding: 8px;
                margin: 4px 0;
                background: #0d1218;
                color: white;
                border: 1px solid #596675;
                border-radius: 5px;
            }

            .lp-mp-panel textarea {
                resize: vertical;
                font: 11px monospace;
            }

            .lp-mp-status {
                padding: 8px;
                border-radius: 6px;
                background: #293541;
            }

            .lp-mp-status[data-kind="ok"] {
                background: #17452e;
            }

            .lp-mp-status[data-kind="warn"] {
                background: #58451d;
            }

            .lp-mp-status[data-kind="error"] {
                background: #5a2525;
            }

            .lp-mp-actions {
                display: flex;
                flex-wrap: wrap;
                gap: 6px;
                margin: 10px 0;
            }

            .lp-mp-chat-log {
                max-height: 120px;
                overflow-y: auto;
                padding: 6px;
                background: #0d1218;
                border-radius: 5px;
                overflow-wrap: anywhere;
            }

            .lp-mp-chat {
                display: flex;
                gap: 5px;
            }

            .lp-mp-chat input {
                flex: 1;
                min-width: 0;
            }

            .lp-mp-collapsed {
                width: 112px;
                height: 40px;
                overflow: hidden;
                padding: 5px 8px;
            }

            .lp-mp-collapsed > :not(.lp-mp-header) {
                display: none;
            }
        `;

        document.head.appendChild(style);
    }

    // ========================================================
    // DÉMARRAGE
    // ========================================================

    installStyles();
    installMenu();

    window.LaPlaineAPI?.on('game:ready', startGame);

    window.addEventListener('pagehide', shutdown);

    console.info(
        `[La Plaine Multiplayer] Core ${CONFIG.version} chargé.`
    );

})();
