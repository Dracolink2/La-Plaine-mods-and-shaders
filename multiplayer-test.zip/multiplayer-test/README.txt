MULTIPLAYER TEST — v0.4.0
Compatible avec La Plaine 0.2.7.0 (protocole multijoueur 3).

INSTALLATION
Place le dossier multiplayer-test dans extras/mods (ou mods) du jeu, puis active le mod dans le menu Mods. Aucun mod Custom Skins n’est requis : les avatars distants utilisent les skins intégrés à La Plaine.

CONNEXION P2P
Le mod utilise WebRTC en étoile : chaque joueur se connecte directement à l’hôte, qui relaie les paquets de jeu. Les données de jeu ne passent pas par un serveur de partie central.

Pour chaque joueur invité, l’hôte crée une invitation et lui envoie le code. Le joueur rejoint avec ce code, puis renvoie son code de réponse à l’hôte. L’hôte valide cette réponse. Répéter pour chaque participant. L’hôte peut accueillir jusqu’à 29 autres joueurs (30 au total).

La signalisation reste manuelle : aucun service central n’est fourni pour échanger automatiquement les offres WebRTC. Selon les routeurs et pare-feu, la connexion directe peut échouer. Cette version configure un serveur STUN public, sans relais TURN garanti.

SYNCHRONISATION
- Positions et orientations, santé, inventaires et skins intégrés des joueurs.
- Changements de blocs et état initial modifié du monde.
- Dimension active, cycle jour/nuit, météo et mobs, sous autorité de l’hôte.
- Chat multijoueur.
- Chaque joueur conserve sa sauvegarde locale.
- Le panneau MP est réduit par défaut ; clique sur OUVRIR pour afficher les contrôles.

LIMITES
- L’hôte relaie les données : son débit montant et les performances de son ordinateur limitent le nombre de joueurs réellement supportés. La limite de 30 est configurée, mais doit être éprouvée sur un vrai réseau à plusieurs clients.
- Les joueurs doivent utiliser La Plaine 0.2.7.0, la même version du mod et les mêmes mods de contenu.
- Les coffres partagés, fours, montures, projectiles et anti-triche ne sont pas pris en charge.
