(() => {
    'use strict';

    const SIZE = 192;
    const RADIUS = 14;
    const CELL = SIZE / (RADIUS * 2 + 1);
    const remotePlayers = new Map();
    let world = null;
    let player = null;
    let camera = null;
    let canvas = null;
    let context = null;
    let lastDraw = 0;
    let destroyed = false;

    function addStyles() {
        if (document.getElementById('lp-minimap-style')) return;
        const style = document.createElement('style');
        style.id = 'lp-minimap-style';
        style.textContent = `
            #lp-minimap { position:fixed; z-index:900; top:14px; right:14px; width:${SIZE}px; padding:7px; border:1px solid #ffffff45; border-radius:10px; background:#101820c9; color:#f4f7f4; font:12px/1.2 Arial,sans-serif; box-shadow:0 3px 14px #0006; pointer-events:none; }
            #lp-minimap canvas { display:block; width:${SIZE}px; height:${SIZE}px; border-radius:6px; image-rendering:pixelated; }
            #lp-minimap-head { display:flex; justify-content:space-between; padding:1px 3px 6px; }
            #lp-minimap-count { color:#b9d8a8; }
            #lp-minimap-legend { display:flex; justify-content:space-between; padding:6px 3px 1px; color:#cbd3d7; font-size:10px; }
            #lp-minimap-legend i { display:inline-block; width:7px; height:7px; margin-right:4px; border-radius:50%; background:#fff; }
            #lp-minimap-legend .remote i { background:#ff6961; }
            @media (max-width:520px) { #lp-minimap { top:8px; right:8px; transform:scale(.78); transform-origin:top right; } }
        `;
        document.head.appendChild(style);
    }

    function createMap() {
        addStyles();
        const root = document.createElement('aside');
        root.id = 'lp-minimap';
        root.innerHTML = '<div id="lp-minimap-head"><strong>CARTE</strong><span id="lp-minimap-count">solo</span></div><canvas width="384" height="384" aria-label="Minimap"></canvas><div id="lp-minimap-legend"><span><i></i>Toi</span><span class="remote"><i></i>Joueurs</span></div>';
        document.body.appendChild(root);
        canvas = root.querySelector('canvas');
        context = canvas.getContext('2d');
    }

    function colorFor(blockId, height, waterline) {
        if (height < waterline) return '#438ca4';
        const colors = {
            1:'#777b78', 2:'#76523b', 3:'#6e9b4c', 4:'#775638', 5:'#477c42',
            9:'#d6c27b', 11:'#438ca4', 12:'#e9eee9', 13:'#87a7a2',
            16:'#376b43', 17:'#4d5356', 24:'#417b43', 26:'#6da568',
            27:'#659451', 29:'#91a953', 30:'#566d48', 32:'#d76536',
            34:'#4c8247', 36:'#426d45', 37:'#9d4429', 38:'#383b46'
        };
        const shade = Math.max(-22, Math.min(22, (height - 48) * 0.35));
        const base = colors[blockId] || '#718369';
        if (!shade) return base;
        const n = parseInt(base.slice(1), 16);
        const r = Math.max(0, Math.min(255, ((n >> 16) & 255) + shade));
        const g = Math.max(0, Math.min(255, ((n >> 8) & 255) + shade));
        const b = Math.max(0, Math.min(255, (n & 255) + shade));
        return `rgb(${r},${g},${b})`;
    }

    function sampleSurface(x, z) {
        const height = Math.floor(world.getTerrainHeight?.(x, z) ?? 48);
        const sea = Number(world.seaLevel ?? 32);
        if (height < sea) return { height, block: 11 };
        let block = world.getBlockI?.(x, Math.min(255, height), z) || 0;
        if (!block) {
            const biome = world.biomeRegistry?.getBiomeAt?.(x, z, world.perlin);
            block = Number(biome?.surfaceBlock) || 3;
        }
        return { height, block };
    }

    function drawTerrain(cx, cz) {
        context.clearRect(0, 0, SIZE * 2, SIZE * 2);
        context.fillStyle = '#1a2528';
        context.fillRect(0, 0, SIZE * 2, SIZE * 2);
        const unit = CELL * 2;
        const center = SIZE;
        for (let dz = -RADIUS; dz <= RADIUS; dz++) {
            for (let dx = -RADIUS; dx <= RADIUS; dx++) {
                const sample = sampleSurface(cx + dx, cz + dz);
                context.fillStyle = colorFor(sample.block, sample.height, Number(world.seaLevel ?? 32));
                context.fillRect(center + dx * unit, center + dz * unit, unit + 1, unit + 1);
            }
        }
        context.strokeStyle = '#ffffff55';
        context.lineWidth = 2;
        context.strokeRect(1, 1, SIZE * 2 - 2, SIZE * 2 - 2);
    }

    function drawMarker(x, z, centerX, centerZ, color, label, rotation = null) {
        const scale = CELL * 2;
        const px = centerX + (x - player.position.x) * scale;
        const py = centerZ + (z - player.position.z) * scale;
        if (px < 3 || py < 3 || px > SIZE * 2 - 3 || py > SIZE * 2 - 3) return;
        context.save();
        context.translate(px, py);
        if (rotation !== null) {
            context.rotate(-rotation);
            context.beginPath(); context.moveTo(0, -12); context.lineTo(8, 8); context.lineTo(0, 5); context.lineTo(-8, 8); context.closePath();
            context.fillStyle = color; context.fill();
        } else {
            context.beginPath(); context.arc(0, 0, 6, 0, Math.PI * 2); context.fillStyle = '#111a'; context.fill();
            context.beginPath(); context.arc(0, 0, 4, 0, Math.PI * 2); context.fillStyle = color; context.fill();
            if (label) {
                context.font = 'bold 18px Arial'; context.textAlign = 'left'; context.textBaseline = 'middle';
                context.lineWidth = 3; context.strokeStyle = '#101820'; context.strokeText(label, 8, 0); context.fillStyle = '#fff'; context.fillText(label, 8, 0);
            }
        }
        context.restore();
    }

    function render(now = performance.now()) {
        if (destroyed || !world || !player || !context || now - lastDraw < 700) return;
        lastDraw = now;
        const px = Number(player.position?.x) || 0;
        const pz = Number(player.position?.z) || 0;
        drawTerrain(Math.floor(px), Math.floor(pz));
        const center = SIZE;
        const dimension = String(world.currentDimensionId || 'overworld');
        let count = 0;
        for (const [id, remote] of remotePlayers) {
            if (now - remote.receivedAt > 6000) { remotePlayers.delete(id); continue; }
            if (remote.dimension !== dimension) continue;
            drawMarker(remote.x, remote.z, center, center, '#ff6961', remote.nickname?.slice(0, 1) || '•');
            count++;
        }
        const localDimension = world.currentDimensionId || 'overworld';
        drawMarker(px, pz, center, center, '#fff', '', Number(camera?.rotation?.y) || 0);
        const countNode = document.getElementById('lp-minimap-count');
        if (countNode) countNode.textContent = count ? `${count + 1} joueurs` : 'solo';
    }

    function onRemotePlayer(event) {
        const data = event.detail;
        if (!data || typeof data.id !== 'string' || ![data.x, data.z].every(value => Number.isFinite(Number(value)))) return;
        remotePlayers.set(data.id, { ...data, receivedAt: performance.now() });
    }

    function start({ world: gameWorld, player: gamePlayer, camera: gameCamera }) {
        if (!gameWorld || !gamePlayer) return;
        world = gameWorld; player = gamePlayer; camera = gameCamera;
        createMap();
        window.addEventListener('laplaine:multiplayer:player-updated', onRemotePlayer);
        window.addEventListener('laplaine:multiplayer:disconnected', () => remotePlayers.clear());
        window.LaPlaineAPI.on('game:tick', () => render());
        render(performance.now() + 1000);
        console.info('[La Plaine Minimap] Carte activée.');
    }

    window.LaPlaineAPI.on('game:ready', start);
})();
