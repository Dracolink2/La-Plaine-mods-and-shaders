# Minimap

Pour La Plaine 0.2.7.0. Place le dossier `minimap` dans `extras/mods/`, active **Minimap** dans le gestionnaire de mods, puis lance une partie.

La carte en haut à droite montre le terrain autour du joueur. En multijoueur, les autres joueurs apparaissent aussi sur la carte lorsqu’ils sont dans la même dimension et que le mod Multiplayer est activé.
